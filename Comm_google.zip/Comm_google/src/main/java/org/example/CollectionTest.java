package org.example;

import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.GeneralSecurityException;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

class CollectionTest {
    /*
    Les méthodes testables de GoogleAuth sont utilisées dans ce test. Le succès des tests dépendent du succès de ces méthodes,
    on considère que les méthodes de GoogleAuth sont testées si les tests de CollectionTest sont vérifiés.
     */

    @Test
    void add_Carte() throws IOException, ExpectedException {
        Collection collection = new Collection("test_collection");
        Carte card1 = Carte.attempt_card("SDCS-FR009");
        Carte card2 = Carte.attempt_card("SDCS-FR010");
        Carte card3 = Carte.attempt_card("SDCS-FR010");

        try {
            // Ajout de la carte 1
            collection.add_Carte(card1);
            assertEquals(1, collection.getCollec().size());

            // Ajout de la carte 2
            collection.add_Carte(card2);
            assertEquals(2, collection.getCollec().size());

            // Ajout de la carte 3, qui est la même que la carte 2.
            collection.add_Carte(card3);
            assertEquals(2, collection.getCollec().size());
            assertEquals(2, collection.getCollec().get(1).getQuantite()); // On devrait avoir 2 fois la même carte.
        } catch (IOException | ExpectedException e) {
            fail("Exception thrown: " + e.getMessage());
        }
    }

    @Test
    void get_carte() throws IOException, ExpectedException {
        Collection collection = new Collection("test_collection");
        Carte card1 = Carte.attempt_card("SDCS-FR009");
        Carte card2 = Carte.attempt_card("SDCS-FR010");
        Carte card3 = Carte.attempt_card("SDCS-FR011");

        try {
            // Ajout des cartes
            collection.add_Carte(card1);
            collection.add_Carte(card2);
            collection.add_Carte(card3);
            assertEquals("SDCS-FR010", collection.get_carte(1).getCode());
            assertEquals("SDCS-FR011", collection.get_carte(2).getCode());
        } catch (IOException | ExpectedException e) {
            fail("Exception thrown: " + e.getMessage());
        }
    }

    @Test
    void rm_Carte() throws IOException, ExpectedException {
        Collection collection = new Collection("test_collection");
        Carte card1 = Carte.attempt_card("SDCS-FR009");
        Carte card2 = Carte.attempt_card("SDCS-FR010");
        Carte card3 = Carte.attempt_card("SDCS-FR011");

        try {
            // Ajout des cartes
            collection.add_Carte(card1);
            collection.add_Carte(card2);
            collection.add_Carte(card3);
            assertEquals(3, collection.getCollec().size());
            collection.rm_Carte(1);
            assertEquals(2, collection.getCollec().size());
        } catch (IOException | ExpectedException e) {
            fail("Exception thrown: " + e.getMessage());
        }
    }

    @Test
    void afficher_collec() throws IOException, ExpectedException {
        Collection collection = new Collection("test_collection");
        Carte card1 = Carte.attempt_card("SDCS-FR009");
        Carte card2 = Carte.attempt_card("SDCS-FR010");
        Carte card3 = Carte.attempt_card("SDCS-FR011");
        collection.add_Carte(card1);
        collection.add_Carte(card2);
        collection.add_Carte(card3);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);
        collection.afficher_collec();
        String console_output = outputStream.toString();
        assertEquals("test_collection 3\n" +
                "Cyber Dragon Herz\n" +
                "Cyber Pharos\n" +
                "Cyber Valley", console_output.trim().replaceAll("\\r\n", "\n"));
        System.setOut(System.out);
    }

    @Test
    void afficher_carte() throws IOException, ExpectedException {
        Collection collection = new Collection("test_collection");
        Carte card1 = Carte.attempt_card("SDCS-FR009");
        Carte card2 = Carte.attempt_card("SDCS-FR010");
        Carte card3 = Carte.attempt_card("SDCS-FR011");
        collection.add_Carte(card1);
        collection.add_Carte(card2);
        collection.add_Carte(card3);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);
        collection.afficher_carte(0);
        String console_output = outputStream.toString();

        assertEquals("Code sur la carte : SDCS-FR009\n" +
                "Nom de la carte : Cyber Dragon Herz\n" +
                "Prix : 1.15\n" +
                "Quantite : 1\n" +
                "Type : Machine/Effect\n" +
                "ATK : 100\n" +
                "DEF : 100\n" +
                "Niveau : 1\n", console_output.replaceAll("\\r\n", "\n"));
        System.setOut(System.out);
    }

    @Test
    void as_file() throws IOException, ExpectedException {
        Collection collection = new Collection("test_collection");
        Carte card1 = Carte.attempt_card("SDCS-FR009");
        Carte card2 = Carte.attempt_card("SDCS-FR010");
        Carte card3 = Carte.attempt_card("SDCS-FR011");
        collection.add_Carte(card1);
        collection.add_Carte(card2);
        collection.add_Carte(card3);
        collection.as_file();
        String strFile = Files.readString(Path.of("src/appdata_file/to_drive/test_collection.txt"));
        assertEquals("nom:test_collection\n" +
                "SDCS-FR009\n" +
                "SDCS-FR010\n" +
                "SDCS-FR011\n" +
                "EndOftest_collection\n", strFile.replaceAll("\\r\n", "\n"));

    }

    @Test
    void get_collec_from_txt() throws IOException, ExpectedException {
        Collection collection = new Collection("test_collection");
        Carte card1 = Carte.attempt_card("SDCS-FR009");
        Carte card2 = Carte.attempt_card("SDCS-FR010");
        Carte card3 = Carte.attempt_card("SDCS-FR011");
        collection.add_Carte(card1);
        collection.add_Carte(card2);
        collection.add_Carte(card3);
        collection.as_file();
        Collection got = Collection.get_collec_from_txt("src/appdata_file/to_drive/test_collection.txt");
        assertEquals(collection.get_carte(1).getCode(), got.get_carte(1).getCode());

    }

    @Test
    void save_collec_drive() throws IOException, ExpectedException, GeneralSecurityException {
        ArrayList<Collection> listcollections = new ArrayList<Collection>();
        Collection collection0 = new Collection("global");
        Collection collection1 = new Collection("collec_test_1");
        listcollections.add(collection0);
        listcollections.add(collection1);
        Carte card1 = Carte.attempt_card("SDCS-FR009");
        Carte card2 = Carte.attempt_card("SDCS-FR010");
        Carte card3 = Carte.attempt_card("SDCS-FR011");
        Carte card4 = Carte.attempt_card("SDCS-FR012");
        collection0.add_Carte(card1);
        collection0.add_Carte(card2);
        collection1.add_Carte(card3);
        collection1.add_Carte(card4);

        collection0.as_file();
        collection1.as_file();

        GoogleAuth.delete_Appdata_files(GoogleAuth.service_Setup());
        Collection.save_collec_drive(listcollections);
        GoogleAuth.get_Appdata_files(GoogleAuth.service_Setup(), "src/appdata_file/from_drive/");

        Collection back0 = Collection.get_collec_from_txt("src/appdata_file/from_drive/CARDS.txt");
        Collection back1 = Collection.get_collec_from_txt("src/appdata_file/from_drive/Collection_1.txt");

        assertEquals(back0.getName(), collection0.getName());
        assertEquals(back0.get_carte(0).getCode(), collection0.get_carte(0).getCode());
        assertEquals(back1.getName(), collection1.getName());
        assertEquals(back1.get_carte(0).getCode(), collection1.get_carte(0).getCode());
    }

    @Test
    void rm_Collec() throws IOException {
        ArrayList<Collection> listcollections = new ArrayList<Collection>();
        Collection collection0 = new Collection("global");
        Collection collection1 = new Collection("collec_test_1");
        listcollections.add(collection0);
        listcollections.add(collection1);
        assertEquals(2, listcollections.size());
        collection1.rm_Collec(listcollections);
        assertEquals(1, listcollections.size());
    }
}