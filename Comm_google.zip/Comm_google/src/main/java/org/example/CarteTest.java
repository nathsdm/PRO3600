package org.example;

import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CarteTest {

    @Test
    void attempt_card() throws IOException, ExpectedException {
        Carte card1 = Carte.attempt_card("SDCS-EN009");
        Carte card2 = Carte.attempt_card("Cyber Dragon Herz", "SDCS-EN");
        assertEquals(card1.getName(),card2.getName());
        assertEquals(card1.getCode(),card2.getCode());
    }

    @Test
    void afficher() throws IOException, ExpectedException{
        Carte card1 = Carte.attempt_card("SDCS-FR009");

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(outputStream);
        System.setOut(printStream);
        card1.afficher();
        String console_output = outputStream.toString();

        assertEquals("Code sur la carte : SDCS-FR009\n" +
                "Nom de la carte : Cyber Dragon Herz\n" +
                "Prix : 1.15\n" +
                "Quantite : 1\n" +
                "Type : Machine/Effect\n" +
                "ATK : 100\n" +
                "DEF : 100\n" +
                "Niveau : 1\n", console_output.replaceAll("\\r\n", "\n"));
        System.setOut(System.out);
    }

    @Test
    void getLang_cm() throws IOException, ExpectedException{
        assertEquals("language=2",Carte.getLang_cm("FR"));
        assertEquals("language=1",Carte.getLang_cm("EN"));
    }

    @Test
    void get_CMlink() throws IOException, ExpectedException{
        Carte card1 = Carte.attempt_card("SDCS-FR009");
        assertEquals("https://www.cardmarket.com/fr/YuGiOh/Products/Singles/Structure-Deck-Cyber-Strike/Cyber-Dragon-Herz?language=2",card1.get_CMlink());
    }

    @Test
    void isItReal() throws IOException,ExpectedException{
        String test1 = Carte.isItReal("SDCS-EN009");
        assertEquals("Cyber Dragon Herz", test1);
        String test2 = Carte.isItReal("SDCS-EN", "Cyber Dragon Herz");
        assertEquals("SDCS-EN009", test2);
    }

    @Test
    void whatType() throws ExpectedException, IOException{
        assertEquals("Monster", Carte.whatType("Cyber Dragon Herz", "SDCS-EN009"));
    }

    @Test
    void getInfoFromYGO_String() throws ExpectedException,IOException{
        Carte card1 = Carte.attempt_card("SDCS-EN009");
        String out_ygopro = new Scanner(new URL(card1.getLien_ygopro_name()).openStream(), "UTF-8").useDelimiter("\\A").next();
        assertEquals("Cyber Dragon Herz",Carte.getInfoFromYGO_String(out_ygopro, "name"));
    }

    @Test
    void getInfoFromYGO_int() throws IOException,ExpectedException{
        Carte card1 = Carte.attempt_card("SDCS-EN009");
        String out_ygopro = new Scanner(new URL(card1.getLien_ygopro_name()).openStream(), "UTF-8").useDelimiter("\\A").next();
        assertEquals(100,Carte.getInfoFromYGO_int(out_ygopro, "atk"));
    }

    @Test
    void getPriceFromYGO_int() throws IOException,ExpectedException{
        String code_norm="SDCS-EN009";
        Carte card1 = Carte.attempt_card(code_norm);
        String out_ygopro = new Scanner(new URL(card1.getLien_ygopro_name()).openStream(), "UTF-8").useDelimiter("\\A").next();
        String card_sets = out_ygopro.substring(out_ygopro.indexOf("\"card_sets\":"));
        card_sets=card_sets.substring(card_sets.indexOf("["),card_sets.indexOf("]"));
        String set_info="";
        while (set_info.indexOf(code_norm)==-1){
            set_info=card_sets.substring(card_sets.indexOf("{"),card_sets.indexOf("}")+1);
            if (set_info.indexOf(code_norm)==-1){
                card_sets=card_sets.substring(card_sets.indexOf("}")+1);
            }
        }
        assertEquals(card1.getPrix(),Carte.getPriceFromYGO_int(set_info));
    }

    @Test
    void makeYGOPRO_link() throws IOException, ExpectedException{
        String link = Carte.makeYGOPRO_link("Cyber Dragon Herz", "SDCS-FR009");
        assertEquals("https://db.ygoprodeck.com/api/v7/cardinfo.php?name=Cyber%20Dragon%20Herz&language=fr", link);
    }

    @Test
    void makeYGOPRO_link_no_language() throws IOException, ExpectedException{
        String link = Carte.makeYGOPRO_link_no_language("Cyber Dragon Herz");
        assertEquals("https://db.ygoprodeck.com/api/v7/cardinfo.php?name=Cyber%20Dragon%20Herz", link);
    }

    @Test
    void makeYGOPRO_setlink() throws IOException, ExpectedException{
        String link = Carte.makeYGOPRO_setlink("SDCS-EN009");
        assertEquals("https://db.ygoprodeck.com/api/v7/cardsetsinfo.php?setcode=SDCS-EN009", link);
    }
}