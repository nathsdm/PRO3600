package org.example;

import com.google.api.services.drive.Drive;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Scanner;

public class Collection {
    private String name;

    private ArrayList<Carte> collec = new ArrayList<Carte>();

    public Collection(String nom) {
        this.name=nom;
    }

    public void add_Carte(Carte card) throws IOException, ExpectedException{
        String ret;
        try{
            for (int i = 0; i<collec.size(); i++){
                if (collec.get(i).getCode().equals(card.getCode())){
                    collec.get(i).setQuantite(collec.get(i).getQuantite()+1);
                    return;
                }
            }
            collec.add(card);
        }
        catch (Exception e){
            throw new ExpectedException("Quelque chose à échoué lors de l'ajout de la carte "+card.getName()+" à la collection "+this.name);
        }


    }
    public Carte get_carte(int indice) throws IOException, ExpectedException{
        if ((indice>=0) &&(indice<collec.size())){
            try{
                return collec.get(indice);
            }
            catch (Exception e){
                throw e;
            }
        }
        else {
            throw new ExpectedException("La carte n'existe pas.");
        }
    }
    public void rm_Carte(int indice) throws IOException, ExpectedException{
        if ((indice>=0) &&(indice<collec.size())){
            try{
                collec.remove(indice);
            }
            catch (Exception e){
                throw new ExpectedException("Quelque chose à échoué lors de la supression de la carte.");
            }
        }
        else {
            throw new ExpectedException("La carte n'existe pas : indice trop grand");
        }

    }

    public void afficher_collec(){
        System.out.println(name + " " + collec.size());
        for(int i = 0; i<collec.size(); i++){
            System.out.println((collec.get(i)).getName());
        }
    }

    public void afficher_carte(int num) throws ExpectedException{
        if(num<collec.size()) {
            collec.get(num).Afficher();
        }
        else{
            throw new ExpectedException("Out of bounds");
        }
    }

    public String as_file() throws IOException,ExpectedException{
        String contenu="nom:"+name+"\n";
        String filename="src/appdata_file/to_drive/"+this.name+".txt";
        for (int i=0; i<collec.size();i++){
            for (int j=0; j<collec.get(i).getQuantite(); j++){
                contenu=contenu+collec.get(i).getCode()+"\n";
            }
        }
        contenu=contenu+"EndOf"+name;
        try (PrintWriter out = new PrintWriter(filename)) {
            out.println(contenu);
            return(filename);
        }
        catch (Exception e){
            throw e;
        }
    }

    public static Collection get_collec_from_txt (String filename) throws IOException,ExpectedException{
        Scanner scanner = new Scanner(Paths.get(filename), StandardCharsets.UTF_8.name());
        String file = scanner.useDelimiter("\\A").next();
        scanner.close();
        String[] filesplit = file.split("\n");
        String name=filesplit[0].substring(4);
        Collection collec_in=new Collection(name);
        int i =1;
        while (filesplit[i].indexOf("EndOf")==-1){
            try{
                Carte attempt = Carte.attempt_card(filesplit[i]);
                collec_in.add_Carte(attempt);
            }
            catch(Exception e){
                throw e;
            }
            i++;
        }
        System.out.println("returning");
        return collec_in;
        }



    public static void save_collec_drive(ArrayList<Collection> listecollec) throws IOException,ExpectedException, GeneralSecurityException {
        Drive driveService= GoogleAuth.service_Setup();
        String to_send;
        String filename;
        for (int i=0; i<listecollec.size();i++){
            to_send=listecollec.get(i).as_file();
            if (i==0){
                filename="CARDS.txt";
            }
            else{
                filename="Collection_"+Integer.toString(i)+".txt";
            }
            GoogleAuth.send_Appdata_files(driveService,filename,to_send);
        }
    }

    public void rm_Collec(ArrayList<Collection> listecollec) throws  IOException{
        listecollec.remove(this);
    }

    public String getName() {
        return name;
    }

    public ArrayList<Carte> getCollec() {
        return collec;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCollec(ArrayList<Carte> collec) {
        this.collec = collec;
    }
}