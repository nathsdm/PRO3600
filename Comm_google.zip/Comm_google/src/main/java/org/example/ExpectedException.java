package org.example;

public class ExpectedException extends Exception {//exception créée pour faire remonter des erreurs prévisibles dues à des errerus en entrée des fonctions.
    public ExpectedException(String errorMessage) {
        super(errorMessage);
    }
}

