package org.example;

public class ExpectedException extends Exception {
    public ExpectedException(String errorMessage) {
        super(errorMessage);
    }
}

