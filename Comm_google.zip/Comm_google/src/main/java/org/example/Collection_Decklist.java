package org.example;/*package org.example;

import java.io.IOException;

public class Collection_Decklist{
    private String name;
    private Collection maindeck;
    private Collection sidedeck;
    private Collection extradeck;
    public Collection_Decklist(String nom){
        this.name=nom;
        maindeck.setSize_max(60);
        sidedeck.setSize_max(15);
        extradeck.setSize_max(15);

    }

    public String afficher_collec() {
        try {
            System.out.println(name);
            System.out.println("Main Deck");
            maindeck.afficher_collec();
            System.out.println("Side Deck");
            sidedeck.afficher_collec();
            System.out.println("Extra Deck");
            extradeck.afficher_collec();
            return("0");
        } catch (Exception e) {
            return ("1Problème");
        }
    }

    String add_Main(Carte card) throws IOException {
        return(maindeck.add_Carte(card));
    }
    String add_Side(Carte card) throws IOException {
        return(sidedeck.add_Carte(card));
    }
    String add_Extra(Carte card) throws IOException {
        return(extradeck.add_Carte(card));
    }
    String add_Carte(Carte card) throws IOException{
        if (card instanceof Carte_monster){
            if (((Carte_monster) card).isItExtra()==true){
                return add_Extra(card);
            }
        }
        return add_Main(card);
    }

    public String rm_Main(int indice, int page) throws IOException {
        return (maindeck.rm_Carte(indice));
    }
    public String rm_Side(int indice, int page) throws IOException {
        return (sidedeck.rm_Carte(indice));
    }
    public String rm_Extra(int indice, int page) throws IOException {
        return (extradeck.rm_Carte(indice));
    }
}
*/