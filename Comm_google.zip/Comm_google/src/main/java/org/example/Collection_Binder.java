/*package org.example;

import java.io.IOException;
import java.util.ArrayList;

public class Collection_Binder{

    private String name;
    private int pages_max;
    private int dim_page;
    private ArrayList<Collection> pages_binder = new ArrayList<Collection>();

    public Collection_Binder(String nom, int dim, int pages){
        this.name=nom;
        this.dim_page=dim;
        this.pages_max=pages;
        for (int i=0; i<pages_max; i++){
            Collection collec_to_add = new Collection("page"+Integer.toString(i));
            collec_to_add.setSize_max(dim);
            pages_binder.add(collec_to_add);
        }
    }

    public String afficher_collec() {
        try {
            System.out.println(name);
            for (int i = 0; i < pages_max; i++) {
                pages_binder.get(i).afficher_collec();
            }
            return("0");
        } catch (Exception e) {
            return ("1Problème");
        }
    }

    public String add_Carte(Carte card, int page) throws IOException {
        if ((page>=0) &&(page<pages_binder.size())){
            return (pages_binder.get(page).add_Carte(card));
        }
        return ("la page n'existe pas");
    }

    public Object get_Carte(int indice_page, int indice_carte) throws IOException{
        if ((indice_page>=0) &&(indice_page<pages_binder.size())){
            try{
                return (pages_binder.get(indice_page)).get_carte(indice_carte);
            }
            catch (Exception e){
                return(e.toString());
            }
        }
        else {
            return ("La carte n'existe pas.");
        }

    }
    public String rm_Carte(int indice, int page) throws IOException,ExpectedException {
        try{
            return (pages_binder.get(page).rm_Carte(indice));
        }
        catch (Exception e){
            throw new ExpectedException("La carte n'existe pas.");
        }
    }

    public void afficher_carte(int page, int card)throws ExpectedException{
        try{
            if (page<pages_max) {
                pages_binder.get(page).afficher_carte(card);
            }
            else{
                throw new ExpectedException("1Indice trop grand pour page");
            }
        }
        catch (Exception e){
            throw e;
        }
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPages_max() {
        return pages_max;
    }

    public void setPages_max(int pages_max) {
        this.pages_max = pages_max;
    }

    public int getDim_page() {
        return dim_page;
    }

    public void setDim_page(int dim_page) {
        this.dim_page = dim_page;
    }

    public ArrayList<Collection> getPages_binder() {
        return pages_binder;
    }

    public void setPages_binder(ArrayList<Collection> pages_binder) {
        this.pages_binder = pages_binder;
    }
}*/
