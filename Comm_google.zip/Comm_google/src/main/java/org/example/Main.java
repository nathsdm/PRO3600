package org.example;

import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;


public class Main {
    public static void main(String[] args) throws IOException, ExpectedException, GeneralSecurityException {
        GoogleAuth.delete_Appdata_files(GoogleAuth.service_Setup());
        ArrayList<String> codes= new ArrayList<String>();
        //codes.add("CT12-EN001");
        //codes.add("SDCS-EN009");
        //codes.add("MGED-FR104");
        //codes.add("RIRA-FR045");
        codes.add("SDCS-EN001");
        codes.add("SDCS-EN002");
        codes.add("SDCS-EN003");
        codes.add("SDCS-EN003");
        codes.add("SDCS-EN003");
        codes.add("SDCS-EN004");
        codes.add("erreur deliberee");
        codes.add("SDCS-EN006");
        codes.add("SDCS-EN023");
        codes.add("SDCS-EN035");
        codes.add("SDCS-EN009");
        codes.add("SDCS-EN010");
        codes.add("SDCS-EN011");
        codes.add("SDCS-EN012");
        codes.add("SDCS-EN013");
        codes.add("SDCS-EN014");
        codes.add("SDCS-EN015");
        codes.add("SDCS-EN016");
        codes.add("SDCS-EN017");
        codes.add("SDCS-EN018");
        codes.add("SDCS-EN019");
        codes.add("SDCS-EN020");
        codes.add("SDCS-EN041");
        codes.add("SDCS-EN042");
        codes.add("SDCS-EN043");

        ArrayList<Collection> listcollections = new ArrayList<Collection>();

        /////////////////////CREATION COLLECTIONS
        Collection global = new Collection("global");
        listcollections.add(global);
        /*Collection part1 = new Collection("part1");
        listcollections.add(part1);
        Collection part2 = new Collection("part2");
        listcollections.add(part2);*/


        /////////////////////////AJOUT CARTES
        for (int i = 0; i<codes.size();i++){
            try {
                global.add_Carte(Carte.attempt_card(codes.get(i)));
            }
            catch(Exception e)
            {
                System.out.println(e.toString());
            }
        }
        System.out.println("global");

        /*for (int i = 0; i<codes.size()/2;i++){
            try {

                part1.add_Carte(Carte.attempt_card(codes.get(i)));
                //System.out.println("Ajout réussi");
            }
            catch(Exception e)
            {
                System.out.println(e.toString());
            }
        }
        System.out.println("collec1");

        for (int i=codes.size()/2; i<codes.size();i++){
            try {

                part2.add_Carte(Carte.attempt_card(codes.get(i)));
                //System.out.println("Ajout réussi");
            }
            catch(Exception e)
            {
                System.out.println(e.toString());
            }
        }
        System.out.println("collec2");*/


        /////////////////SAVE DANS LE DRIVE
        try{
            GoogleAuth.delete_Appdata_files(GoogleAuth.service_Setup());
            Collection.save_collec_drive(listcollections);
            System.out.println("Les fichiers ont bien ete crees.");
        }catch (Exception e){
            System.out.println(e.toString());
        }
        FileList files = GoogleAuth.get_Appdata_files(GoogleAuth.service_Setup(),"src/appdata_file/from_drive/");
        for(File file : files.getFiles()){
            System.out.println(file);
        }

        listcollections = new ArrayList<Collection>();
        listcollections.add(Collection.get_collec_from_txt("src/appdata_file/from_drive/CARDS.txt"));
        //listcollections.add(Collection.get_collec_from_txt("src/appdata_file/from_drive/Collection_1.txt"));
        //listcollections.add(Collection.get_collec_from_txt("src/appdata_file/from_drive/Collection_2.txt"));
        listcollections.get(0).afficher_collec();
        //listcollections.get(1).afficher_collec();
        //listcollections.get(2).afficher_collec();
        listcollections.get(0).afficher_carte(2);

    }


}