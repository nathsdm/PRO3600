package org.example;

public class Collection {
    String name;
    int icone;


}
