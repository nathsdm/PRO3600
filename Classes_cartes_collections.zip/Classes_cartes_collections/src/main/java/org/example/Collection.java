package org.example;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class Collection {
    private String name;
    private int size_max;

    private ArrayList<Carte> collec = new ArrayList<Carte>();

    public Collection(String nom) {
        this.name=nom;
    }

    public String add_Carte(Carte card) throws IOException{
        String ret;
        if ((size_max<=0)||(collec.size()<size_max)){
            try{
                collec.add(card);
                ret = "0Ajout reussi";
                return(ret);
            }
            catch (Exception e){
                ret = e.toString();
                return(ret);
            }
        }
        else {
            ret = "La collection est pleine.";
            return (ret);
        }

    }
    public Carte get_carte(int indice) throws IOException, ExpectedException{
        if ((indice>=0) &&(indice<collec.size())){
            try{
                return collec.get(indice);
            }
            catch (Exception e){
                throw e;
            }
        }
        else {
            throw new ExpectedException("La carte n'existe pas.");
        }
    }
    public String rm_Carte(int indice) throws IOException, ExpectedException{
        if ((indice>=0) &&(indice<collec.size())){
            try{
                collec.remove(indice);
                return "0";
            }
            catch (Exception e){
                return(e.toString());
            }
        }
        else {
            throw new ExpectedException("La carte n'existe pas.");
        }

    }

    public void afficher_collec(){
        System.out.println(name + " " + collec.size());
        for(int i = 0; i<collec.size(); i++){
            System.out.println((collec.get(i)).getName());
        }
    }

    public void afficher_carte(int num) throws ExpectedException{
        if(num<collec.size()) {
            collec.get(num).Afficher();
        }
        else{
            throw new ExpectedException("Out of bounds");
        }
    }

    public void as_file() throws IOException,ExpectedException{
        String contenu="";
        contenu=contenu+"Collection\n";
        contenu=contenu+"nom:"+name+"\n";
        contenu=contenu+"size_max:"+size_max+"\n";
        for (int i=0; i<collec.size();i++){
            contenu=contenu+collec.get(i).getCode()+"\n";
        }
        contenu=contenu+"EndOf"+name;
        try (PrintWriter out = new PrintWriter("filename.txt")) {
            out.println(contenu);
        }
        catch (Exception e){
            throw e;
        }
    }

    public static Collection get_collec_from_txt (String filename) throws IOException,ExpectedException{

        Scanner scanner = new Scanner(Paths.get("filename.txt"), StandardCharsets.UTF_8.name());
        String file = scanner.useDelimiter("\\A").next();
        scanner.close();
        String[] filesplit = file.split("\n");
        if (filesplit[0].equals("Collection")){
            String name=filesplit[1].substring(4);
            int size=Integer.parseInt(filesplit[2].substring(9));
            Collection collec_in=new Collection(name);
            collec_in.setSize_max(size);
            int i=3;
            while(filesplit[i].indexOf("EndOf")==-1){
                try{
                    Carte attempt = Carte.attempt_card(filesplit[i]);
                    collec_in.add_Carte(attempt);
                }
                catch(Exception e){
                    throw e;
                }
                i++;
            }
            System.out.println("returning");
            return collec_in;
        }
        else {
            throw new IOException("Ce fichier n'est pas adapté.");
        }

    }

    public String getName() {
        return name;
    }

    public int getSize_max() {
        return size_max;
    }

    public ArrayList<Carte> getCollec() {
        return collec;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSize_max(int size_max) {
        this.size_max = size_max;
    }

    public void setCollec(ArrayList<Carte> collec) {
        this.collec = collec;
    }
}
