package org.example;

import java.io.File;

public class Carte_Wanted extends Carte{
    public Carte_Wanted(String name, File image, String type, String lien_cm, String rarete, float prix, int lang_id, String etat) {
        super(name, image, type, lien_cm, rarete, prix, lang_id, etat);
    }
}
