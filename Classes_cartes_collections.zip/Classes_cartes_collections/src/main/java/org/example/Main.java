package org.example;


import java.io.IOException;
import java.net.URL;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) throws IOException {


        //https://db.ygoprodeck.com/api/v7/cardinfo.php?name=Cyber%20Dragon%20Herz
        //Instantiating the URL class
        String code = "SDCS-FR009";
        String cardset = "https://db.ygoprodeck.com/api/v7/cardsetsinfo.php?setcode=";
        String card = "https://db.ygoprodeck.com/api/v7/cardinfo.php";
        String lang_str = code.substring(code.indexOf('-')+1,code.indexOf('-')+3);
        String lang_id; //voir CardMarket

        code = code.substring(0,code.indexOf('-')+1)+"EN"+code.substring(code.indexOf('-')+3);

        cardset = cardset+code;

        String out = new Scanner(new URL(cardset).openStream(), "UTF-8").useDelimiter("\\A").next();
        System.out.println(cardset);
        out = out.substring(out.indexOf(",")+1);

        String name = out.substring(out.indexOf("\"name\":\"")+8, out.indexOf("\","));
        name=name.replace(" ","-");

        out = out.substring(out.indexOf(",")+1);

        String setname = out.substring(out.indexOf("\"set_name\":\"")+12, out.indexOf("\","));
        setname=setname.replace(" ","-");
        setname=setname.replace(":","");


        //https://www.cardmarket.com/fr/YuGiOh/Products/Singles/Structure-Deck-Cyber-Strike/Cyber-Dragon-Herz
        String lien_cm = "https://www.cardmarket.com/fr/YuGiOh/Products/Singles/"+setname+"/"+name;
        System.out.println(lien_cm);

        String cm_out = new Scanner(new URL(lien_cm).openStream(), "UTF-8").useDelimiter("\\A").next();

    }
}