package org.example;

//UTILISER YGOPRICES APIAIRY
//cardmarket requirt un identifiant, il faut les contacter, y a toute une procédure, ... c'est mort
//ducoup pas de variance du prix en fonction de la 1ère édition, ...
//on va quand même générer le lien cardmarket et le mettre à disposition.
import java.io.IOException;
import java.net.URL;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {

        String code_inc = "DUDE-EN";
        String name = "Silent Graveyard";

        /*String code_inc = "MP19-EN";
        String name="Danger! Nessie!";*/

        /*String code_inc = "MRD-E";
        String name="Harpie Lady";*/

        /*String code_inc="LOB-";
        String name = "Pot of Greed";*/

        Object test = Carte.attempt_card(name,code_inc);

        /*String lang_id = code_inc.substring(code_inc.indexOf('-')+1);
        lang_id = lang_id.replaceAll("\\d","");
        if (lang_id.length()>2){
            lang_id = lang_id.substring(0,2);
        }
        code_inc = code_inc.substring(0,code_inc.indexOf("-")+1)+lang_id;
        //on s'assure que le code est incomplet.

        String res = Carte.isItReal(code_inc,name);
        if (res.indexOf("0")!=0){
            System.out.println(res.substring(1));
            return;
        }
        String code = code_inc+res.substring((res.length()-3), res.length());
        String type = Carte.whatType(name,code);
        Carte card1;
        switch (type){
            case "Monster":
                card1 = new Carte_monster(code,name);
                break;
            case "Spell":
                card1 = new Carte_spell(code,name);
                break;
            case "Trap":
                card1 = new Carte_trap(code,name);
                break;
            default:
                card1 = new Carte(code,name);
        }*/
        if (test instanceof String){
            System.out.println((String) test);
            return;
        }
        if (test instanceof Carte){
            Carte card1 = (Carte) test;
            card1.Afficher();
        }
        Object test2 = Carte.attempt_card("SDCS-EN009");
        if (test2 instanceof String){
            System.out.println((String) test2);
            return;
        }
        if (test2 instanceof Carte){
            Carte card2 = (Carte) test2;
            card2.Afficher();
        }



    }

}