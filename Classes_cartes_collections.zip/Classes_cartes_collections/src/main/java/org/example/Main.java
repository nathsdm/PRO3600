package org.example;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {

        /*String code_inc = "DUDE-EN";
        String name = "Silent Graveyard";*/

        String code_inc = "MP19-EN";
        String name="Danger! Nessie!";

        /*String code_inc = "MRD-E";
        String name="Harpie Lady";*/

        /*String code_inc="LOB-";
        String name = "Pot of Greed";*/

        /*Object test = Carte.attempt_card(name,code_inc);

        if (test instanceof String){
            System.out.println((String) test);
            return;
        }
        if (test instanceof Carte){
            Carte card1 = (Carte) test;
            card1.Afficher();
        }

        System.out.print("\n \n");

        //String code1 ="CT12-EN001";//odd-eyes pendulum dragon
        //String code1 ="SDCS-EN009";//cyber dragon herz
        //String code1 = "MGED-FR104";//code talker
        String code1 = "RIRA-FR045";//berserker of the tenyi
        Object test2 = Carte.attempt_card(code1);


        if (test2 instanceof String){
            System.out.println((String) test2);
            return;
        }
        if (test2 instanceof Carte){
            Carte card2 = (Carte) test2;
            card2.Afficher();
        }*/

        ArrayList<String> codes= new ArrayList<String>();
        /*codes.add("CT12-EN001");
        codes.add("SDCS-EN009");
        codes.add("MGED-FR104");
        codes.add("RIRA-FR045");*/
        codes.add("SDCS-EN001");
        codes.add("SDCS-EN002");
        codes.add("SDCS-EN003");
        codes.add("SDCS-EN004");
        codes.add("erreur deliberee");
        codes.add("SDCS-EN006");
        codes.add("SDCS-EN023");
        codes.add("SDCS-EN035");
        /*codes.add("SDCS-EN009");
        codes.add("SDCS-EN010");
        codes.add("SDCS-EN011");
        codes.add("SDCS-EN012");
        codes.add("SDCS-EN013");
        codes.add("SDCS-EN014");
        codes.add("SDCS-EN015");
        codes.add("SDCS-EN016");
        codes.add("SDCS-EN017");
        codes.add("SDCS-EN018");
        codes.add("SDCS-EN019");
        codes.add("SDCS-EN020");
        codes.add("SDCS-EN041");
        codes.add("SDCS-EN042");
        codes.add("SDCS-EN043");*/


        Collection global = new Collection("global");
        //Collection collec = new Collection("bruh", 2);
        //collec.setSize_max(2);
        //Collection_Binder collec_binder = new Collection_Binder("binder1",8,10);


        //binder
        /*for (int i = 0; i<codes.size();i++){
            Object attempt = Carte.attempt_card(codes.get(i));
            if (attempt instanceof String){
                System.out.println((String) attempt);
                return;
            }
            if (attempt instanceof Carte){
                String ret = collec_binder.add_Carte((Carte) attempt, i/collec_binder.getDim_page());
                System.out.println(ret);
            }
        }*/

        //collec simple
        for (int i = 0; i<codes.size();i++){
            try {

                String ret = global.add_Carte(Carte.attempt_card(codes.get(i)));
                System.out.println(ret);
            }
            catch(Exception e)
            {
                System.out.println(e.toString());
            }
        }

        //collec_binder.afficher_collec();
        //collec_binder.afficher_carte(2,1);
        //collec_binder.afficher_carte(1,1);
        global.afficher_collec();
        try{
            global.as_file();
            System.out.println("Le fichier a bien ete cree.");
        }catch (Exception e){
            System.out.println(e.toString());
        }
        //System.out.println(global.as_file());
        Scanner scanner = new Scanner(Paths.get("filename.txt"), StandardCharsets.UTF_8.name());
        String file = scanner.useDelimiter("\\A").next();
        scanner.close();
        System.out.println(file);

        Collection collec_2;
        try{
            collec_2 = Collection.get_collec_from_txt("filename.txt");
            collec_2.afficher_collec();
            collec_2.afficher_carte(5);
            collec_2.afficher_carte(10);
        }
        catch (Exception e){
            System.out.println(e.toString());
        }
    }


}