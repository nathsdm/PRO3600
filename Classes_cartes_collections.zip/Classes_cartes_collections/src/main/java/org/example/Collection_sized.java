package org.example;

public class Collection_sized extends Collection{
    int size;
    Carte[] liste;

}
