package org.example;

import java.io.File;
public class Carte {
    //image, nom, type, lien, rareté, prix
    private String name;
    private File image;
    private String type;
    private String lien_cm;
    private String rarete;
    private float prix;
    private int lang_id;
    private String etat;


    public Carte(String name, File image, String type, String lien_cm, String rarete, float prix, int lang_id, String etat){
        this.name=name;
        this.image=image;
        this.type=type;
        this.lien_cm=lien_cm;
        this.rarete=rarete;
        this.prix=prix;
        this.lang_id=lang_id;
        this.etat=etat;
    }

    //AddToCollection
    //RemoveFromCollection
    //Remove

}
