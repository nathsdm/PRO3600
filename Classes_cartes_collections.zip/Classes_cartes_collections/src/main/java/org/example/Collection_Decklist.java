package org.example;

public class Collection_Decklist extends Collection{
}
