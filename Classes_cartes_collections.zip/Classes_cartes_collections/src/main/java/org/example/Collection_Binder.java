package org.example;

public class Collection_Binder extends Collection{

    private int dim_x;
    private int dim_y;
    //collection_sized

}
