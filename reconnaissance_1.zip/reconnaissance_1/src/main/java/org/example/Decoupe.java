package org.example;

import org.opencv.core.Mat;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.Buffer;

public class Decoupe {

    static BufferedImage Slicing(BufferedImage image) { // nul mais marche un peu
        BufferedImage result = new BufferedImage(
                image.getWidth(),
                image.getHeight(),
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.drawImage(image, 0, 0, Color.WHITE, null);

        Color blue = new Color(0, 0, 255);

        double isBlacker = 0;
        for (int i = 0; i < image.getWidth(); i++) {
            int moyg = 0;
            for (int j = 0; j < image.getHeight(); j++) {
                Color c = new Color(image.getRGB(i, j));
                int red = (int) (c.getRed());
                moyg = moyg + red;
            }
            System.out.println(moyg*1.0/image.getHeight());
            isBlacker = isBlacker + moyg*1.0/image.getHeight();

        }
        System.out.println("moy : "+isBlacker/image.getWidth());
        isBlacker=isBlacker/image.getWidth();
        for (int i = 0; i < image.getWidth(); i++) {
            int moyg = 0;
            for (int j = 0; j < image.getHeight(); j++) {
                Color c = new Color(image.getRGB(i, j));
                int red = (int) (c.getRed());
                moyg = moyg + red;
            }
            if (moyg*1.0/image.getHeight()>isBlacker){
                for (int j = 0; j < image.getHeight(); j++) {
                    result.setRGB(i, j, blue.getRGB());
                }
            }

        }
        return (result);
    }



    static BufferedImage upsAndDowns(BufferedImage image, int window){
        BufferedImage result = new BufferedImage(
                image.getWidth(),
                image.getHeight(),
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.drawImage(image, 0, 0, Color.WHITE, null);

        Color green = new Color(0, 255, 0);
        Color red = new Color(255, 0, 0);
        Color orange = new Color(255, 150, 0);

        for (int i = window; i < image.getWidth(); i++) {
            double moywindow = 0;
            for (int k = i-window; k < i; k++) {
                for (int j = 0; j < image.getHeight(); j++) {
                    Color c = new Color(image.getRGB(k, j));
                    int grey = (int) (c.getRed());
                    moywindow = moywindow + grey;
                }
            }
            double moyl = 0;
            for (int j = 0; j < image.getHeight(); j++) {
                Color c = new Color(image.getRGB(i, j));
                int grey = (int) (c.getRed());
                moyl = moyl + grey;
            }
            moyl=moyl/image.getHeight();
            System.out.println(moyl);

            moywindow=moywindow/(window*image.getHeight());
            System.out.println(moywindow);
            System.out.println(Math.abs(moyl-moywindow));
            if (Math.abs(moyl-moywindow)>5){
                for (int j = 0; j < 10; j++) {
                    result.setRGB(i, j, orange.getRGB());
                }
            } else if (moyl-moywindow<0) {
                for (int j = 0; j < 5; j++) {
                    result.setRGB(i, j, red.getRGB());
                }
            } else if (moyl-moywindow>0) {
                for (int j = 0; j < 5; j++) {
                    result.setRGB(i, j, green.getRGB());
                }
            }

        }




        return(result);
    }


    static BufferedImage histogramme(BufferedImage image) throws IOException {
        BufferedImage result = new BufferedImage(
                image.getWidth(),
                256,
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.setColor(new Color(255, 255, 255));
        graphic.drawRect(0, 0, result.getWidth(), result.getHeight());

        graphic.fillRect(0, 0, result.getWidth(), result.getHeight());

        Color black = new Color(0, 0, 0);

        Color red = new Color (255,0,0);

        for (int i = 0; i < image.getWidth(); i++) {
            int moy = 0;
            for (int j = 0; j < image.getHeight(); j++) {
                Color c = new Color(image.getRGB(i, j));
                int grey = (int) (c.getRed());
                moy = moy + grey;
            }
            moy=moy/image.getHeight();
            result.setRGB(i, moy, black.getRGB());

        }
        int moy = ProcessImage.getMoyenne(image);
        for (int i = 0; i < image.getWidth(); i++) {
            result.setRGB(i, moy, red.getRGB());
        }



        return(result);
    }

    static BufferedImage split (BufferedImage image, int coeff) throws IOException {
        BufferedImage result = new BufferedImage(
                image.getWidth(),
                image.getHeight(),
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.drawImage(image, 0, 0, Color.WHITE, null);
        int slice = image.getWidth()/coeff;
        for (int l = 0; l<coeff; l++){
            BufferedImage coeffslice = new BufferedImage(
                    slice,
                    image.getHeight(),
                    BufferedImage.TYPE_INT_RGB);

            for (int i=slice*l; i<slice*(l+1); i++){
                for (int j=0; j<image.getHeight();j++){
                    Color c = new Color(image.getRGB(i, j));
                    coeffslice.setRGB(i-(l*slice),j, c.getRGB());
                }
            }
            BufferedImage grey = ProcessImage.toGray(coeffslice);

            coeffslice = ProcessImage.EnlargeSpecter(grey);

            coeffslice = ProcessImage.uselessLines(coeffslice);

            //coeffslice = ProcessImage.cleanse(coeffslice);

            //DisplayImage.DisplayTheImage(coeffslice);

            for (int i=slice*l; i<slice*(l+1); i++){
                for (int j=0; j<image.getHeight();j++){
                    Color c = new Color(coeffslice.getRGB(i-(slice*l), j));
                    result.setRGB(i,j, c.getRGB());
                }
            }
        }

        /*result = ProcessImage.filterMedian(result, 3);
        DisplayImage.DisplayTheImage(result);*/
        return (result);
    }



    public static BufferedImage fromMiddle (BufferedImage image){
        BufferedImage result = new BufferedImage(
                image.getWidth(),
                image.getHeight(),
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.drawImage(image, 0, 0, Color.WHITE, null);
        //Color blue = new Color (0,0,255);

        int firstline=-1;
        int longueur=0;

        int firstlinekeep=-1;
        int longueurkeep=0;
        for(int j = 0; j<image.getHeight(); j++){
            int sum=0;
            for (int i=0;i<image.getWidth();i++){
                Color c = new Color(image.getRGB(i, j));
                int red = (int) (c.getRed());
                sum = sum + red;
            }
            if ((sum<0.9*255*image.getWidth()) && (j != image.getHeight()-1)){
                //0 is dark
                //1 is light
                if (firstline==-1){
                    firstline=j;
                }
                longueur++;
                //result.setRGB(0,j, blue.getRGB());
            }
            else
            if (firstline!=-1){
                System.out.println("firstline : "+firstline+", lastline : "+(firstline+longueur)+", longueur : "+longueur);

                //if ((firstline>3) && (firstline+longueur<image.getWidth()-3) && (longueur>longueurkeep)){
                if (longueur>longueurkeep){
                    firstlinekeep = firstline;
                    longueurkeep=longueur;
                }

                firstline=-1;
                longueur=0;
            }
        }
        Color white = new Color (255,255,255);
        for(int j = 0; j<image.getHeight(); j++) {
            for (int i = 0; i < image.getWidth(); i++) {
                if ((j>firstlinekeep+longueurkeep) || (j<firstlinekeep)){
                    result.setRGB(i,j, white.getRGB());
                }
            }
        }
        return (result);
    }




    public static BufferedImage splitGroups (BufferedImage image) throws IOException{
        BufferedImage result = new BufferedImage(
                image.getWidth(),
                image.getHeight(),
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.drawImage(image, 0, 0, Color.WHITE, null);

        int[][] result2Dmat = new int[image.getWidth()][image.getHeight()];

        for (int j = 1; j<image.getHeight(); j++) {
            for (int i = 1; i < image.getWidth(); i++) {
                Color c = new Color(image.getRGB(i, j));
                int red = (int) (c.getRed());
                result2Dmat[i][j]=(red/255)*-1;
            }
        }
/*
        for (int j = 1; j<image.getHeight()-1; j++) {
            for (int i = image.getWidth() - 1; i>1; i--) {
                System.out.print(result2Dmat[i][j]+ " ");
            }
            System.out.println();
        }*/

        //etape 1
        int etiquette = 1;

        for (int j = 1; j<image.getHeight()-1; j++) {
            for (int i = 1; i < image.getWidth() - 1; i++) {

                int red = result2Dmat[i][j];

                if (red != -1){ //is black
                    int red1 = result2Dmat[i][j-1];
                    int red2 = result2Dmat[i-1][j];
                    if ((red1!=-1) || (red2!=-1)){
                        if (red1 == -1){
                            result2Dmat[i][j] = red2;
                        } else if (red2 == -1) {
                            result2Dmat[i][j] = red1;
                        }
                        else {
                            result2Dmat[i][j] = Math.min(red1,red2);
                        }
                    }
                    else {
                        result2Dmat[i][j] = etiquette;
                        etiquette++;
                        }
                    }
                }
            }

        /*for (int j = 1; j<image.getHeight()-1; j++) {
            for (int i = image.getWidth() - 1; i>1; i--) {
                System.out.print(result2Dmat[i][j]+ " ");
            }
            System.out.println();
        }*/

        //etape2
        for (int j = image.getHeight()-2; j>1; j--) {
            for (int i = image.getWidth() - 2; i>1; i--) {
                int red = result2Dmat[i][j];
                if (red != -1){ //is black
                    int red1 = result2Dmat[i][j+1];
                    int red2 = result2Dmat[i+1][j];
                    if ((red1!=-1) || (red2!=-1)){
                        if (red1 == -1){
                            result2Dmat[i][j] = Math.min(red2,red);
                        } else if (red2 == -1) {
                            result2Dmat[i][j] = Math.min(red1,red);
                        }
                        else {
                            result2Dmat[i][j] = Math.min(Math.min(red1,red2),red);
                        }
                    }
                }
            }
        }

        /*for (int j = 1; j<image.getHeight()-1; j++) {
            for (int i = image.getWidth() - 1; i>1; i--) {
                System.out.print(result2Dmat[i][j]+ " ");
            }
            System.out.println();
        }*/
        //etape3
        for (int j = 1; j<image.getHeight()-2; j++) {
            for (int i = image.getWidth() - 2; i>1; i--) {
                int red = result2Dmat[i][j];
                int red1 = result2Dmat[i][j+1];
                int red2 = result2Dmat[i-1][j];
                if ((red1!=-1) || (red2!=-1)){
                    if (red1 == -1){
                        result2Dmat[i][j] = Math.min(red2,red);
                    } else if (red2 == -1) {
                        result2Dmat[i][j] = Math.min(red1,red);
                    }
                    else {
                        result2Dmat[i][j] = Math.min(Math.min(red1,red2),red);
                    }
                }
            }
        }

        for (int j = 1; j<image.getHeight()-1; j++) {
            for (int i = image.getWidth() - 1; i>1; i--) {
                System.out.print(result2Dmat[i][j]+ " ");
            }
            System.out.println();
        }

        return (result);
    }



}
