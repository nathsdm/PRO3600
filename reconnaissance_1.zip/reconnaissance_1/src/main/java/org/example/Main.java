package org.example;

import java.io.File;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.photo.Photo;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;


//cropping du bruit, ou crop par ratio.
//prévoir des photos moches qui marchent pas.
public class Main {
    public static void main(String[] args) throws IOException {

        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);


        //String input = "src/main/images/synchro.jpg";//cyber-dragon-herz-code_0.jpg";//debordement-cybernetique_code_0.jpg";

        //BATCH DE MAI
        //String input = "src/main/images_mai/codes/1elfe_mystique.jpg";
        //String input = "src/main/images_mai/noms/2Cylindre_magique.jpg";
        //String input = "src/main/images_mai/codes/3anki_en.jpg";
        //String input = "src/main/images_mai/codes/4appel_des_tenebres.jpg";
        //String input = "src/main/images_mai/codes/5bellcat.jpg";
        //String input = "src/main/images_mai/codes/6bipbip.jpg";
        String input = "src/main/images_mai/codes/7cyberse_integrator.jpg";//marche parfaitement;
        //String input = "src/main/images_mai/codes/8maestroke.jpg";
        //String input = "src/main/images_mai/codes/9soldat_du_lustre_noir.jpg";


        //a tester : sangan, synchro, xyz avec l'inverse, debordement, herz, crop de core.
        /*
        xyz : kernel7, pas d'amélioration
        sangan : mort, sans amelioration, photo trop nulle.
        synchro : kernel7 avec amelio, sinon OK
        deb : OK
        herz : presque parfait avec les améliorations (plus de bruit), bof sans amélioration (lettres en morceau, marche avec k5), pb avec les chiffres.
         */
        String output = "src/main/images/result.png";
        File input_file = new File (input);
        File output_file = new File (output);
        //File input_file = new File ("D:\\Ubuntu\\Dossier_Partage\\images\\xyz.jpg");
        //File input_file = new File ("/media/sf_Dossier_Partage/images/debordement-cybernetique_code_0.jpg");
        // BufferedImage img = ImageIO.read(input_file);


        /*
        SE RENSEIGNER SUR LES PATTERNS
        Problème sur la taille des kernels : augmenter jusqu'à que ça soit bon, mais quand est-ce bon ?
         */


        Mat src = Imgcodecs.imread(input);
        Imgproc.cvtColor(src, src, Imgproc.COLOR_BGR2GRAY);

        //Core.bitwise_not(src,src); //inversion xyz

         //amelioration !!! moins de bruit, plus de points ?
        //Photo.fastNlMeansDenoising(src,src);
        //Imgproc.equalizeHist(src,src);


        //Imgproc.erode(src, src, kernel5);
        //Imgproc.dilate(src, src, kernel3);

        Mat blur = new Mat();
        Imgproc.medianBlur(src, blur, 5);
        Imgproc.adaptiveThreshold(blur,src, 255, Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C, Imgproc.THRESH_BINARY,31,2);


        /*Imgproc.dilate(src, src, kernel(5));
        Imgproc.erode(src, src, kernel(7));*/



        Imgproc.dilate(src, src, kernel(5));
        Imgproc.erode(src, src, kernel(7));



        Imgcodecs.imwrite(output,src);

        //output_file=new File ("src/main/images/result_nocont_synchro.png");



        /*BufferedImage img = ImageIO.read(output_file);
        img = ProcessImage.EnlargeSpecter(img);
        ImageIO.write(img, "png", output_file);*/

        BufferedImage img = ImageIO.read(output_file);
        /*
        érosions dilatations ici
         */

        img = Decoupe.fromMiddle(img);    //byebye les bandes de bruit en haut en bas
        //DisplayImage.DisplayTheImage(img);
        //img = Decoupe.splitGroups(img);
        DisplayImage.DisplayTheImage(img);


        String text = tesserText(img);
        System.out.println(text);
        text=text.replaceAll("[^AZERTYUIOPQSDFGHJKLMWXCVBN1234567890-]","");

        String ed = text.substring(0, text.indexOf("-"));
        String num = text.substring(text.length()-3);
        String lang = text.substring(text.indexOf("-")+1,text.indexOf("-")+3);

        System.out.println(text.length());

        String num_f="";
        if (num.charAt(0)=='O'){
            num_f=num_f+"0";
        }
        else {
            num_f=num_f+num.charAt(0);
        }
        for (int i=1; i<num.length();i++){
            char fix = num.charAt(i);
            if (Character.isLetter(num.charAt(i))==true){
                fix = fixNumber(fix);
            }
            num_f=num_f+fix;
        }
        System.out.println(ed+"-"+lang+num_f);



        /*
        BufferedImage img = ImageIO.read(input_file);
        //di.DisplayImage(img);
        //System.out.print(Integer.toBinaryString(img.getRGB(0, 0)));

        //System.out.print(ProcessImage.IsLinkCard(img));

        BufferedImage grey = ProcessImage.toGray(img);


        BufferedImage split4 = Decoupe.split(grey,4);
        DisplayImage.DisplayTheImage(split4);


        BufferedImage split8 = Decoupe.split(grey,8);
        DisplayImage.DisplayTheImage(split8);

        tesserText(split8);
        tesserText(split4);

        /*

        //DisplayImage.DisplayTheImage(img);
        BufferedImage grey = ProcessImage.toGray(img);
        DisplayImage.DisplayTheImage(grey);
        BufferedImage greyEn = ProcessImage.EnlargeSpecter(grey);
        DisplayImage.DisplayTheImage(greyEn);
        BufferedImage greyUseless = ProcessImage.uselessLines(greyEn);
        DisplayImage.DisplayTheImage(greyUseless);


        BufferedImage median = ProcessImage.filterMedian(greyEn, 3);
        //DisplayImage.DisplayTheImage(median);

        //BufferedImage greyUselessC = ProcessImage.uselessColumns(median);
        //DisplayImage.DisplayTheImage(greyUselessC);
        //BufferedImage greyUseless = ProcessImage.uselessLines(median);
        //DisplayImage.DisplayTheImage(greyUseless);
        BufferedImage bigImage1 = ProcessImage.biggerImage(greyEn, 2);

        //bigImage1 = ProcessImage.filterMedian(bigImage1, 3);
        //DisplayImage.DisplayTheImage(bigImage1);
        bigImage1 = ProcessImage.uselessLines(bigImage1);
        //DisplayImage.DisplayTheImage(bigImage1);
        bigImage1 = ProcessImage.filterMedian(bigImage1, 5);
        DisplayImage.DisplayTheImage(bigImage1);
        tesserText(bigImage1);



        //SEPARER LES LETTRES REGION PAR REGION, FILTRER SUR CHACUNE DE CES REGIONS.
        //SEPARER L'IMAGE EN MORCEAUX



        File outputfile = new File("D:\\Ubuntu\\Dossier_Partage\\images\\result.png");
        ImageIO.write(bigImage1, "png", outputfile);

        File paint_file = new File ("D:\\Ubuntu\\Dossier_Partage\\images\\result_3.png");
        BufferedImage paint = ImageIO.read(paint_file);
        DisplayImage.DisplayTheImage(paint);
        tesserText(paint);


        */

    }

    static String tesserText(BufferedImage imageIn){

        try {
            Tesseract tesseract = new Tesseract();
            tesseract.setTessVariable("tessedit_char_whitelist", "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ-");
            tesseract.setTessVariable("load_system_dawg", "false");
            tesseract.setTessVariable("load_freq_dawg", "false");
            tesseract.setTessVariable("chop_enable", "true");
            tesseract.setTessVariable("enable_new_segsearch", "0");
            //tesseract.setPageSegMode(11);
            tesseract.setDatapath("src/main/Tess4J-3.4.8-src/Tess4J/tessdata");
            //tesseract.setHocr(true);
            // NE MARCHE PAS COMME SUR LINUX : RAISON ???
            //String text = tesseract.doOCR(new File("D:\\Ubuntu\\Dossier_Partage\\images\\result.png"));
            String text = tesseract.doOCR(imageIn);
            // path of your image file
            //System.out.print(text);
            return (text);
        }
        catch (TesseractException e) {
            e.printStackTrace();
        }
        return (null);

    }
    static Mat kernel (int num){
        return (Imgproc.getStructuringElement(Imgproc.MORPH_RECT,
                new Size(num,num)));
    }
    static char fixNumber (char in){
        char out = in;
        switch (out){
            case 'A':
                out = '4';
                break;
            case 'B':
                out = '8';
                break;
            case 'C':
                out = '0';
                break;
            case 'D':
                out = '0';
                break;
            case 'E':
                out = '8';
                break;
            case 'F':
                out = '7';
                break;
            case 'G':
                out = '6';
                break;
            case 'H':
                out = '8';
                break;
            case 'I':
                out = '1';
                break;
            case 'J':
                out = '1';
                break;
            case 'K':
                out = '8';
                break;
            case 'L':
                out = '1';
                break;
            case 'O':
                out = '0';
                break;
            case 'P':
                out = '9';
                break;
            case 'Q':
                out = '0';
                break;
            case 'R':
                out = '9';
                break;
            case 'S':
                out = '5';
                break;
            case 'T':
                out = '7';
                break;
            case 'U':
                out = '0';
                break;
            case 'V':
                out = '0';
                break;
            case 'Y':
                out = '1';
                break;
            case 'Z':
                out = '2';
                break;

        }

        return (out);
    }
}