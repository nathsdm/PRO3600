package org.example;

import java.io.File;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Main {
    public static void main(String[] args) throws IOException {

        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);


        String input = "src/main/images/debordement-cybernetique_code_0.jpg";
        String output = "src/main/images/result.png";
        File input_file = new File (input);
        File output_file = new File (output);
        //File input_file = new File ("D:\\Ubuntu\\Dossier_Partage\\images\\xyz.jpg");
        //File input_file = new File ("/media/sf_Dossier_Partage/images/debordement-cybernetique_code_0.jpg");
        // BufferedImage img = ImageIO.read(input_file);


        Mat src = Imgcodecs.imread(input);
        Mat src2 = new Mat();
        Imgproc.cvtColor(src, src2, Imgproc.COLOR_BGR2GRAY);
        Mat kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT,
                new Size((2*2) + 1, (2*2)+1));
        Mat src3 = new Mat();
        Imgproc.dilate(src2, src3, kernel);
        Mat src4 = new Mat();
        Imgproc.erode(src3, src4, kernel);
        Mat src5 = new Mat();
        Mat blur = new Mat();
        Imgproc.medianBlur(src4, blur, 5);

        Imgproc.adaptiveThreshold(blur,src5, 255, Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C, Imgproc.THRESH_BINARY,31,2);



        Imgcodecs.imwrite(output,src5);

        BufferedImage img = ImageIO.read(output_file);

        DisplayImage.DisplayTheImage(img);
        tesserText(img);





        /*
        BufferedImage img = ImageIO.read(input_file);
        //di.DisplayImage(img);
        //System.out.print(Integer.toBinaryString(img.getRGB(0, 0)));

        //System.out.print(ProcessImage.IsLinkCard(img));

        BufferedImage grey = ProcessImage.toGray(img);


        BufferedImage split4 = Decoupe.split(grey,4);
        DisplayImage.DisplayTheImage(split4);


        BufferedImage split8 = Decoupe.split(grey,8);
        DisplayImage.DisplayTheImage(split8);

        tesserText(split8);
        tesserText(split4);

        /*

        //DisplayImage.DisplayTheImage(img);
        BufferedImage grey = ProcessImage.toGray(img);
        DisplayImage.DisplayTheImage(grey);
        BufferedImage greyEn = ProcessImage.EnlargeSpecter(grey);
        DisplayImage.DisplayTheImage(greyEn);
        BufferedImage greyUseless = ProcessImage.uselessLines(greyEn);
        DisplayImage.DisplayTheImage(greyUseless);


        BufferedImage median = ProcessImage.filterMedian(greyEn, 3);
        //DisplayImage.DisplayTheImage(median);

        //BufferedImage greyUselessC = ProcessImage.uselessColumns(median);
        //DisplayImage.DisplayTheImage(greyUselessC);
        //BufferedImage greyUseless = ProcessImage.uselessLines(median);
        //DisplayImage.DisplayTheImage(greyUseless);
        BufferedImage bigImage1 = ProcessImage.biggerImage(greyEn, 2);

        //bigImage1 = ProcessImage.filterMedian(bigImage1, 3);
        //DisplayImage.DisplayTheImage(bigImage1);
        bigImage1 = ProcessImage.uselessLines(bigImage1);
        //DisplayImage.DisplayTheImage(bigImage1);
        bigImage1 = ProcessImage.filterMedian(bigImage1, 5);
        DisplayImage.DisplayTheImage(bigImage1);
        tesserText(bigImage1);



        //SEPARER LES LETTRES REGION PAR REGION, FILTRER SUR CHACUNE DE CES REGIONS.
        //SEPARER L'IMAGE EN MORCEAUX



        File outputfile = new File("D:\\Ubuntu\\Dossier_Partage\\images\\result.png");
        ImageIO.write(bigImage1, "png", outputfile);

        File paint_file = new File ("D:\\Ubuntu\\Dossier_Partage\\images\\result_3.png");
        BufferedImage paint = ImageIO.read(paint_file);
        DisplayImage.DisplayTheImage(paint);
        tesserText(paint);


        */

    }

    static void tesserText(BufferedImage imageIn){

        try {
            Tesseract tesseract = new Tesseract();
            tesseract.setTessVariable("tessedit_char_whitelist", "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ-");
            //tesseract.setTessVariable("load_system_dawg", "false");
            //tesseract.setTessVariable("load_freq_dawg", "false");
            //tesseract.setPageSegMode(11);
            tesseract.setDatapath("D:\\Ubuntu\\Dossier_Partage\\Tess4J-3.4.8-src\\Tess4J\\tessdata");
            //tesseract.setHocr(true);
            // NE MARCHE PAS COMME SUR LINUX : RAISON ???
            //String text = tesseract.doOCR(new File("D:\\Ubuntu\\Dossier_Partage\\images\\result.png"));
            String text = tesseract.doOCR(imageIn);
            // path of your image file
            System.out.print(text);
        }
        catch (TesseractException e) {
            e.printStackTrace();
        }

    }
}