package org.example;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
public class ProcessImage {
    static public BufferedImage toGray(BufferedImage image) throws IOException {
        BufferedImage result = new BufferedImage(
                image.getWidth(),
                image.getHeight(),
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.drawImage(image, 0, 0, Color.WHITE, null);

        for (int i = 0; i < result.getHeight(); i++) {
            for (int j = 0; j < result.getWidth(); j++) {
                Color c = new Color(result.getRGB(j, i));
                int red = (int) (c.getRed() * 0.299);
                int green = (int) (c.getGreen() * 0.587);
                int blue = (int) (c.getBlue() * 0.114);
                Color newColor = new Color(
                        red + green + blue,
                        red + green + blue,
                        red + green + blue);
                result.setRGB(j, i, newColor.getRGB());
            }
        }

        return(result);
    }




    static public BufferedImage uselessLines(BufferedImage image) throws IOException {
        BufferedImage result = new BufferedImage(
                image.getWidth(),
                image.getHeight(),
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.drawImage(image, 0, 0, Color.WHITE, null);
        int moy = getMoyenne(image);
        for (int i = 0; i < image.getHeight(); i++) {
            int add=0;
            for (int j = 0; j < image.getWidth(); j++) {
                Color c = new Color(image.getRGB(j, i));
                int red = (int) (c.getRed());
                add=add+red;
            }
            add=add/image.getWidth();
            for (int j = 0; j < image.getWidth(); j++) {

                Color c = new Color(image.getRGB(j,i));
                int red = (int) (c.getRed());
                red = (int) (red*(moy*1.0/add));

                if (red/255 >= 1) {
                    red=255;
                }

                if (red>moy-(moy/10)){
                    red = 255;
                }/*
                else{
                    red = 0;
                }
                */
                Color newColor = new Color(red,red,red);
                result.setRGB(j, i, newColor.getRGB());

            }
        }


        return(result);
    }



    /*static public BufferedImage uselessColumns(BufferedImage image) throws IOException {
        BufferedImage result = new BufferedImage(
                image.getWidth(),
                image.getHeight(),
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.drawImage(image, 0, 0, Color.WHITE, null);
        int moy = getMoyenne(image);
        for (int i = 0; i < image.getWidth(); i++) {
            int add=0;
            for (int j = 0; j < image.getHeight(); j++) {
                Color c = new Color(image.getRGB(i, j));
                int red = (int) (c.getRed());
                add=add+red;
            }
            add=add/image.getHeight();
            for (int j = 0; j < image.getHeight(); j++) {

                Color c = new Color(image.getRGB(i,j));
                int red = (int) (c.getRed());
                red = (int) (red*(moy*1.0/add));

                if (red/255 >= 1) {
                    red=255;
                }
                Color newColor = new Color(red,red,red);
                result.setRGB(i, j, newColor.getRGB());

            }
        }


        return(result);
    }*/






    static public int getMax (BufferedImage image) {
        int result = 0;
        for (int i = 0; i < image.getHeight(); i++) {
            for (int j = 0; j < image.getWidth(); j++) {
                Color c = new Color(image.getRGB(j, i));
                int red = (int) (c.getRed());
                if (red>result) {
                    result = red;
                }
            }
        }
        return(result);
    }

    static public int getMin (BufferedImage image) {
        int result = 255;
        for (int i = 0; i < image.getHeight(); i++) {
            for (int j = 0; j < image.getWidth(); j++) {
                Color c = new Color(image.getRGB(j, i));
                int red = (int) (c.getRed());
                if (red<result) {
                    result = red;
                }
            }
        }
        return(result);
    }

    static public int getMoyenne(BufferedImage image) throws IOException {
        int result =0;

        for (int i = 0; i < image.getHeight(); i++) {
            for (int j = 0; j < image.getWidth(); j++) {
                Color c = new Color(image.getRGB(j, i));
                int red = (int) (c.getRed());
                result = result + red;
            }
        }
        result=result/(image.getHeight() * image.getWidth());
        return(result);
    }



    static public BufferedImage EnlargeSpecter(BufferedImage image) throws IOException {
        BufferedImage result = new BufferedImage(
                image.getWidth(),
                image.getHeight(),
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.drawImage(image, 0, 0, Color.WHITE, null);
        int min=255;
        int max=0;
        max=getMax(image);
        min=getMin(image);



        for (int i = 0; i < image.getHeight(); i++) {
            for (int j = 0; j < image.getWidth(); j++) {
                Color c = new Color(image.getRGB(j, i));
                int red = (int) (c.getRed());
                red = (red-min)*(255/(max-min));
                Color newColor = new Color(red,red,red);
                result.setRGB(j, i, newColor.getRGB());
            }
        }

        return(result);
    }



    public static BufferedImage filterMedian(BufferedImage img,int MSIZE) {


        int x, y, i, j;
        int r;
        final int[] val = new int[MSIZE * MSIZE];
        final int w = img.getWidth();
        final int h = img.getHeight();
        final BufferedImage dst = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);

        for (y = 0; y < h; y++) {
            for (x = 0; x < w; x++) {
                dst.setRGB(x, y, Color.WHITE.getRGB());
            }
        }

        for (y = MSIZE / 2; y < h - MSIZE / 2; y++) {
            for (x = MSIZE / 2; x < w - MSIZE / 2; x++) {
                for (i = 0; i < MSIZE; i++) {
                    for (j = 0; j < MSIZE; j++) {
                        r = new Color(img.getRGB(x + j - MSIZE / 2, y + i - MSIZE / 2)).getRed();
                        val[i * MSIZE + j] = r;
                    }
                }
                /* Bubble sort power! */
                for (i = 0; i < MSIZE * MSIZE / 2 + 1; i++) {
                    for (j = i + 1; j < MSIZE * MSIZE; j++) {
                        if (val[i] > val[j]) {
                            final int k = val[i];
                            val[i] = val[j];
                            val[j] = k;
                        }
                    }
                }
                i = val[MSIZE * MSIZE / 2];
                dst.setRGB(x, y, new Color(i, i, i).getRGB());
            }
        }
        return dst;
    }


    static boolean IsLinkCard (BufferedImage image) { // nul mais marche un peu
        int isRedder = 0;
        for (int i = 1; i < image.getHeight(); i++) {
            int moyg=0;
            for (int j = 0; j < image.getWidth()/2; j++) {
                Color c = new Color(image.getRGB(j, i));
                int red = (int) (c.getRed());
                moyg=moyg+red;
            }
            moyg=moyg/image.getWidth()/2;

            int moyd=0;
            for (int j = image.getWidth()/2 +1; j < image.getWidth(); j++) {
                Color c = new Color(image.getRGB(j, i));
                int red = (int) (c.getRed());
                moyd=moyd+red;
            }
            moyd=moyd/image.getWidth()/2;

            if (moyd>1.5*moyg) {
                isRedder=isRedder+1;
            }
            else
            {
                isRedder=0;
            }

            if (isRedder>=5) {
                return(true);
            }
        }
        return(false);
    }


    static BufferedImage biggerImage (BufferedImage image, int coeff){
        BufferedImage result = new BufferedImage(
                image.getWidth()*coeff,
                image.getHeight()*coeff,
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.drawImage(image, 0, 0, Color.WHITE, null);

        for (int i = 0; i < image.getHeight(); i++) {
            for (int j = 0; j < image.getWidth(); j++) {
                Color c = new Color(image.getRGB(j, i));
                for (int k=0; k < coeff; k++){
                    for (int l=0; l< coeff; l++){
                        result.setRGB(j*coeff+k, i*coeff+l, c.getRGB());
                    }
                }
            }
        }

        return result;

    }


    static BufferedImage invert (BufferedImage image){
        BufferedImage result = new BufferedImage(
                image.getWidth(),
                image.getHeight(),
                BufferedImage.TYPE_INT_RGB);

        Graphics2D graphic = result.createGraphics();
        graphic.drawImage(image, 0, 0, Color.WHITE, null);

        for (int i = 0; i < image.getHeight(); i++) {
            for (int j = 0; j < image.getWidth(); j++) {
                Color c = new Color(image.getRGB(j, i));
                int red = (int) (c.getRed());
                Color newColor = new Color(255-red,255-red,255-red);
                result.setRGB(j, i, newColor.getRGB());
            }
        }

        return result;

    }



}
